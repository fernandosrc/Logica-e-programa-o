﻿namespace formsss19calculadora2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnadicao = new System.Windows.Forms.Button();
            this.lblinteiro = new System.Windows.Forms.Label();
            this.lbldecimal = new System.Windows.Forms.Label();
            this.txtinteiro = new System.Windows.Forms.TextBox();
            this.txtdecimal = new System.Windows.Forms.TextBox();
            this.btnsubtracao = new System.Windows.Forms.Button();
            this.btnmultiplicacao = new System.Windows.Forms.Button();
            this.btndivisao = new System.Windows.Forms.Button();
            this.btnresultado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnadicao
            // 
            this.btnadicao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnadicao.Location = new System.Drawing.Point(81, 304);
            this.btnadicao.Name = "btnadicao";
            this.btnadicao.Size = new System.Drawing.Size(152, 36);
            this.btnadicao.TabIndex = 0;
            this.btnadicao.Text = " adição";
            this.btnadicao.UseVisualStyleBackColor = false;
            this.btnadicao.Click += new System.EventHandler(this.btnresultado_Click);
            // 
            // lblinteiro
            // 
            this.lblinteiro.AutoSize = true;
            this.lblinteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinteiro.Location = new System.Drawing.Point(78, 49);
            this.lblinteiro.Name = "lblinteiro";
            this.lblinteiro.Size = new System.Drawing.Size(96, 33);
            this.lblinteiro.TabIndex = 1;
            this.lblinteiro.Text = "Inteiro";
            this.lblinteiro.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbldecimal
            // 
            this.lbldecimal.AutoSize = true;
            this.lbldecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldecimal.Location = new System.Drawing.Point(75, 196);
            this.lbldecimal.Name = "lbldecimal";
            this.lbldecimal.Size = new System.Drawing.Size(122, 33);
            this.lbldecimal.TabIndex = 2;
            this.lbldecimal.Text = "Decimal";
            this.lbldecimal.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtinteiro
            // 
            this.txtinteiro.Location = new System.Drawing.Point(84, 127);
            this.txtinteiro.Name = "txtinteiro";
            this.txtinteiro.Size = new System.Drawing.Size(125, 20);
            this.txtinteiro.TabIndex = 3;
            // 
            // txtdecimal
            // 
            this.txtdecimal.Location = new System.Drawing.Point(84, 255);
            this.txtdecimal.Name = "txtdecimal";
            this.txtdecimal.Size = new System.Drawing.Size(125, 20);
            this.txtdecimal.TabIndex = 4;
            // 
            // btnsubtracao
            // 
            this.btnsubtracao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnsubtracao.Location = new System.Drawing.Point(81, 366);
            this.btnsubtracao.Name = "btnsubtracao";
            this.btnsubtracao.Size = new System.Drawing.Size(152, 36);
            this.btnsubtracao.TabIndex = 5;
            this.btnsubtracao.Text = " subtração";
            this.btnsubtracao.UseVisualStyleBackColor = false;
            // 
            // btnmultiplicacao
            // 
            this.btnmultiplicacao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnmultiplicacao.Location = new System.Drawing.Point(527, 304);
            this.btnmultiplicacao.Name = "btnmultiplicacao";
            this.btnmultiplicacao.Size = new System.Drawing.Size(149, 36);
            this.btnmultiplicacao.TabIndex = 6;
            this.btnmultiplicacao.Text = "multiplicação";
            this.btnmultiplicacao.UseVisualStyleBackColor = false;
            // 
            // btndivisao
            // 
            this.btndivisao.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btndivisao.Location = new System.Drawing.Point(527, 366);
            this.btndivisao.Name = "btndivisao";
            this.btndivisao.Size = new System.Drawing.Size(149, 36);
            this.btndivisao.TabIndex = 7;
            this.btndivisao.Text = "divisão";
            this.btndivisao.UseVisualStyleBackColor = false;
            this.btndivisao.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnresultado
            // 
            this.btnresultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnresultado.Location = new System.Drawing.Point(516, 96);
            this.btnresultado.Name = "btnresultado";
            this.btnresultado.Size = new System.Drawing.Size(213, 117);
            this.btnresultado.TabIndex = 8;
            this.btnresultado.Text = "resultado";
            this.btnresultado.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnresultado);
            this.Controls.Add(this.btndivisao);
            this.Controls.Add(this.btnmultiplicacao);
            this.Controls.Add(this.btnsubtracao);
            this.Controls.Add(this.txtdecimal);
            this.Controls.Add(this.txtinteiro);
            this.Controls.Add(this.lbldecimal);
            this.Controls.Add(this.lblinteiro);
            this.Controls.Add(this.btnadicao);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnadicao;
        private System.Windows.Forms.Label lblinteiro;
        private System.Windows.Forms.Label lbldecimal;
        private System.Windows.Forms.TextBox txtinteiro;
        private System.Windows.Forms.TextBox txtdecimal;
        private System.Windows.Forms.Button btnsubtracao;
        private System.Windows.Forms.Button btnmultiplicacao;
        private System.Windows.Forms.Button btndivisao;
        private System.Windows.Forms.Button btnresultado;
    }
}

