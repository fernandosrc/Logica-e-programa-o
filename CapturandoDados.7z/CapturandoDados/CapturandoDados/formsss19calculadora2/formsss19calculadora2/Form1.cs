﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formsss19calculadora2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
      
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnresultado_Click(object sender, EventArgs e)
        {

            int varInteiro = int.Parse(txtinteiro.Text);
            float varDecimal = float.Parse(txtdecimal.Text);
            float resultado;

            //soma
            resultado = varInteiro + varDecimal;
            MessageBox.Show("soma: " + resultado);

            //subtração

            resultado = varInteiro - varDecimal;
            MessageBox.Show("subtração: " + resultado);

            //multiplicação
            resultado = varInteiro * varDecimal;
            MessageBox.Show("multiplicação: " + resultado);

            //divisão
            resultado = varInteiro / varDecimal;
            MessageBox.Show("divisão: " + resultado);

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
