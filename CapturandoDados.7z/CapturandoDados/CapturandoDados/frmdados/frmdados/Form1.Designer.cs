﻿namespace frmdados
{
    partial class Formdados
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formdados));
            this.txtBoleano = new System.Windows.Forms.TextBox();
            this.txTexto = new System.Windows.Forms.TextBox();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblTexto = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBoleano
            // 
            this.txtBoleano.Location = new System.Drawing.Point(516, 144);
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(182, 20);
            this.txtBoleano.TabIndex = 0;
            this.txtBoleano.TextChanged += new System.EventHandler(this.txtBoleano_TextChanged);
            // 
            // txTexto
            // 
            this.txTexto.Location = new System.Drawing.Point(516, 282);
            this.txTexto.Name = "txTexto";
            this.txTexto.Size = new System.Drawing.Size(182, 20);
            this.txTexto.TabIndex = 1;
            // 
            // txtInteiro
            // 
            this.txtInteiro.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtInteiro.Location = new System.Drawing.Point(84, 144);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(174, 20);
            this.txtInteiro.TabIndex = 2;
            this.txtInteiro.TextChanged += new System.EventHandler(this.txtInteiro_TextChanged);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(84, 282);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(174, 20);
            this.txtDecimal.TabIndex = 3;
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.Location = new System.Drawing.Point(80, 117);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(66, 24);
            this.lblInteiro.TabIndex = 4;
            this.lblInteiro.Text = "Inteiro:";
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoleano.Location = new System.Drawing.Point(512, 117);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(85, 24);
            this.lblBoleano.TabIndex = 5;
            this.lblBoleano.Text = "Boleano:";
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimal.Location = new System.Drawing.Point(80, 255);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(83, 24);
            this.lblDecimal.TabIndex = 6;
            this.lblDecimal.Text = "Decimal:";
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(512, 255);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(63, 24);
            this.lblTexto.TabIndex = 7;
            this.lblTexto.Text = "Texto:";
            this.lblTexto.Click += new System.EventHandler(this.lblTexto_Click);
            // 
            // btnEnviar
            // 
            this.btnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviar.ForeColor = System.Drawing.Color.Black;
            this.btnEnviar.Location = new System.Drawing.Point(84, 376);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(174, 39);
            this.btnEnviar.TabIndex = 8;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.Black;
            this.btnLimpar.Location = new System.Drawing.Point(516, 376);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(182, 39);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // Formdados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(777, 422);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.txTexto);
            this.Controls.Add(this.txtBoleano);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Formdados";
            this.Text = "Capturando dados ";
//            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoleano;
        private System.Windows.Forms.TextBox txTexto;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnLimpar;
    }
}

