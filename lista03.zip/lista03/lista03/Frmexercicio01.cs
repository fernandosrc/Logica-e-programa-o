﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista03
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void lblnum3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //capturar os valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float soma;

            //Realizar a soma
            soma = num1 + num2 + num3;

            //Mostrar resultado
            MessageBox.Show("Soma = " + soma);

            //Mostrar resultado
        }

        private void btnporcentagem_Click(object sender, EventArgs e)
        {
            //capturar valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float porcentagem1, porcentagem2, porcentagem3;

            //Calculos
            porcentagem1 = num1 / (num1 + num2 + num3) + 100;
            porcentagem2 = num2 / (num1 + num2 + num3) + 100;
            porcentagem3 = num3 / (num1 + num2 + num3) + 100;

            //mostrar resultado
            MessageBox.Show("Porcentagem num1= " + porcentagem1);
            MessageBox.Show("Porcentagem num2= " + porcentagem2);
            MessageBox.Show("Porcentagem num3= " + porcentagem3);
        }



        private void btnmedia_Click(object sender, EventArgs e)
        {
            //capturar valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float media;

            //calcular a media
            media = (num1 + num2 + num3) / 3;

            //mostrar resultado
            MessageBox.Show("Media= " + media);
        }
    }
}
