﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista03
{
    public partial class Frmexercicio02 : Form
    {
        public Frmexercicio02()
        {
            InitializeComponent();
        }
    }
}
