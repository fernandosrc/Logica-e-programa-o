﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Fernando
{
    public partial class Frmteste : Form
    {
        public Frmteste()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnresultado_Click(object sender, EventArgs e)
        {
            //pegar valores na tela
            int qtdpaes = int.Parse(txtpaes.Text);
            int qtdbroas = int.Parse(txtbroas.Text);
            float total;

            //fazer o calculo
            total = qtdpaes * 0.12f + qtdbroas * 1.50f;

            //mostrar o resultado em uma label
            lblvalor.Text = "R$" + total;
        }
    }
}
