﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Fernando
{
    public partial class Frmteste2 : Form
    {
        public Frmteste2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //pegar os valores na tela
            int qtdP = int.Parse(txtP.Text);
            int qtdM = int.Parse(txtM.Text);
            int qtdG = int.Parse(txtG.Text);
            float total;

            //fazer o calculo
            total= (qtdP*21) + (qtdM*25) + (qtdG*30);

            //mostrar resultado em uma label 
            lblvalor.Text = "R$" + total;
        }
    }
}
