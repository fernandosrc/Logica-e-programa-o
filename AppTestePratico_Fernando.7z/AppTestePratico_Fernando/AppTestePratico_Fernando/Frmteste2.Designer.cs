﻿namespace AppTestePratico_Fernando
{
    partial class Frmteste2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.lblP = new System.Windows.Forms.Label();
            this.lblM = new System.Windows.Forms.Label();
            this.lblG = new System.Windows.Forms.Label();
            this.txtP = new System.Windows.Forms.TextBox();
            this.txtM = new System.Windows.Forms.TextBox();
            this.txtG = new System.Windows.Forms.TextBox();
            this.lblvalor = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(563, 88);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(155, 58);
            this.button1.TabIndex = 0;
            this.button1.Text = "resultado";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblP
            // 
            this.lblP.AutoSize = true;
            this.lblP.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP.Location = new System.Drawing.Point(155, 88);
            this.lblP.Name = "lblP";
            this.lblP.Size = new System.Drawing.Size(136, 31);
            this.lblP.TabIndex = 1;
            this.lblP.Text = "camisas p";
            // 
            // lblM
            // 
            this.lblM.AutoSize = true;
            this.lblM.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblM.Location = new System.Drawing.Point(155, 174);
            this.lblM.Name = "lblM";
            this.lblM.Size = new System.Drawing.Size(143, 31);
            this.lblM.TabIndex = 2;
            this.lblM.Text = "camisas m";
            // 
            // lblG
            // 
            this.lblG.AutoSize = true;
            this.lblG.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblG.Location = new System.Drawing.Point(155, 252);
            this.lblG.Name = "lblG";
            this.lblG.Size = new System.Drawing.Size(136, 31);
            this.lblG.TabIndex = 3;
            this.lblG.Text = "camisas g";
            // 
            // txtP
            // 
            this.txtP.Location = new System.Drawing.Point(161, 126);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(117, 20);
            this.txtP.TabIndex = 4;
            // 
            // txtM
            // 
            this.txtM.Location = new System.Drawing.Point(161, 208);
            this.txtM.Name = "txtM";
            this.txtM.Size = new System.Drawing.Size(117, 20);
            this.txtM.TabIndex = 5;
            // 
            // txtG
            // 
            this.txtG.Location = new System.Drawing.Point(161, 286);
            this.txtG.Name = "txtG";
            this.txtG.Size = new System.Drawing.Size(117, 20);
            this.txtG.TabIndex = 6;
            // 
            // lblvalor
            // 
            this.lblvalor.AutoSize = true;
            this.lblvalor.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvalor.Location = new System.Drawing.Point(476, 251);
            this.lblvalor.Name = "lblvalor";
            this.lblvalor.Size = new System.Drawing.Size(91, 33);
            this.lblvalor.TabIndex = 7;
            this.lblvalor.Text = "Valor:";
            // 
            // Frmteste2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblvalor);
            this.Controls.Add(this.txtG);
            this.Controls.Add(this.txtM);
            this.Controls.Add(this.txtP);
            this.Controls.Add(this.lblG);
            this.Controls.Add(this.lblM);
            this.Controls.Add(this.lblP);
            this.Controls.Add(this.button1);
            this.Name = "Frmteste2";
            this.Text = "Frmteste2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblP;
        private System.Windows.Forms.Label lblM;
        private System.Windows.Forms.Label lblG;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.TextBox txtM;
        private System.Windows.Forms.TextBox txtG;
        private System.Windows.Forms.Label lblvalor;
    }
}